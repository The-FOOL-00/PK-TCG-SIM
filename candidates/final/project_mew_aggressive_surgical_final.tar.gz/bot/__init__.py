"""Bot package."""
