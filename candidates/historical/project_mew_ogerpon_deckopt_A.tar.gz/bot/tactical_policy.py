"""Unified Tactical Policy Layer for BS-CEI V1.5c / V1.7 / Experiment N.

Integrates target-selection priors and energy-attachment sequencing priors into
candidate action filtering, feeding high-equity tactical options directly to the
2-ply pure minimax search engine while strictly preserving Bench Safety.
"""

from typing import List, Dict, Any, Optional, Tuple
import main as agent_mod
from bot.phase_controller import GamePhase
from bot.action_filter import classify_action, ActionClass
from bot.target_selector import evaluate_target_equity
from bot.energy_sequencer import evaluate_attachment_equity


def rank_tactical_candidates(
    options: List[dict],
    cur: dict,
    me: int,
    phase: GamePhase,
    top_k: int = 4,
) -> List[int]:
    """Ranks options using tactical priors and returns top_k candidate indices."""
    if len(options) <= top_k:
        return list(range(len(options)))

    players = cur.get("players") or [{}, {}]
    mine = players[me]
    my_bench = mine.get("bench") or []
    benched_count = sum(1 for p in my_bench if p is not None)

    opp_p = players[1 - me]
    opp_active = (opp_p.get("active") or [{}])[0]
    opp_bench = opp_p.get("bench") or []

    scored_options = []

    for i, opt in enumerate(options):
        cls = classify_action(opt, cur, me, phase)
        otype = opt.get("type", "")
        card_id = opt.get("cardId")
        card_info = agent_mod.CARDS.get(card_id, {}) if card_id else {}
        ctype = card_info.get("cardType", 0)

        # Base score from action class hierarchy
        base_score = 0.0
        if cls == ActionClass.TERMINAL:
            base_score = 100000.0
        elif cls == ActionClass.PREVENT_LOSS:
            base_score = 50000.0
        elif cls == ActionClass.SETUP_BENCH:
            # Critical Bench Safety Invariant
            base_score = 40000.0 if benched_count == 0 else 10000.0
        elif cls == ActionClass.ATTACK:
            base_score = 5000.0
        elif cls == ActionClass.DEVELOPMENT:
            base_score = 3000.0
        elif cls == ActionClass.TRAINER:
            base_score = 2000.0
        elif cls == ActionClass.PASS:
            base_score = 10.0

        # Tactical Bonus 1: Target Selection Equity
        if otype == "attack" or "attack" in str(opt.get("name", "")).lower():
            dmg = opt.get("damage", 130)
            target_slot = opt.get("targetSlot", 0)
            target_mon = opp_active if target_slot == 0 else (opp_bench[target_slot - 1] if target_slot - 1 < len(opp_bench) else {})
            t_score = evaluate_target_equity(target_slot, target_mon, dmg, cur, me)
            base_score += t_score

        # Tactical Bonus 2: Energy Attachment Sequencing
        if ctype == 5 or otype == "attach_energy":
            target_slot = opt.get("targetSlot", 0)
            e_score = evaluate_attachment_equity(target_slot, cur, me)
            base_score += e_score

        scored_options.append((base_score, i))

    scored_options.sort(key=lambda x: (-x[0], x[1]))
    return [idx for _, idx in scored_options[:top_k]]
